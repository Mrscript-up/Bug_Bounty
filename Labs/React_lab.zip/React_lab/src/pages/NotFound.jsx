import { Link } from 'react-router-dom'

function NotFound() {
  return (
    <section className="empty-state not-found-page">
      <p className="eyebrow">404 · Page not found</p>
      <h1>Looks like this page wandered off.</h1>
      <p>Let's get you back to something good.</p>
      <Link className="button button-dark" to="/">Go home</Link>
    </section>
  )
}

export default NotFound
