import { useState } from 'react'
import ProductCard from '../components/ProductCard.jsx'
import SearchBox from '../components/SearchBox.jsx'
import { products } from '../data/products.js'

function Products() {
  // این state در والد نگه‌داری می‌شود و مقدار آن از والد به SearchBox فرزند می‌رسد.
  const [searchText, setSearchText] = useState('')
  const filteredProducts = products.filter((product) => {
    const searchableText = `${product.name} ${product.category}`.toLowerCase()
    return searchableText.includes(searchText.trim().toLowerCase())
  })

  return (
    <section className="listing-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">The collection</p>
          <h1>Products</h1>
          <p className="muted">A small selection of useful, everyday favorites.</p>
        </div>
        {/* در این نمونه، والد مقدار و callback را به فرزند می‌دهد؛ فرزند state والد را مستقیم تغییر نمی‌دهد. */}
        <SearchBox value={searchText} onChange={setSearchText} />
      </div>

      <p className="result-count">{filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'}</p>
      {filteredProducts.length > 0 ? (
        <div className="product-grid">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <span aria-hidden="true">⌕</span>
          <h2>No products found</h2>
          <p>Try a different name or category.</p>
        </div>
      )}
    </section>
  )
}

export default Products
