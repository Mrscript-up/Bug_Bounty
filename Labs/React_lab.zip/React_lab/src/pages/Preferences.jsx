import { useEffect, useState } from 'react'

const preferencesUrl = '/api/preferences'

function Preferences() {
  const [editorValue, setEditorValue] = useState('{}')
  const [preferences, setPreferences] = useState({})
  const [notice, setNotice] = useState('Loading preferences...')

  useEffect(() => {
    fetch(preferencesUrl)
      .then((response) => {
        if (!response.ok) throw new Error('Could not load preferences.')
        return response.json()
      })
      .then((storedPreferences) => {
        setPreferences(storedPreferences)
        setEditorValue(JSON.stringify(storedPreferences, null, 2))
        setNotice('Preferences loaded.')
      })
      .catch((error) => setNotice(error.message))
  }, [])

  async function savePreferences(event) {
    event.preventDefault()

    try {
      const submittedPreferences = JSON.parse(editorValue)
      const response = await fetch(preferencesUrl, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submittedPreferences),
      })

      if (!response.ok) throw new Error('Could not save preferences.')

      const storedPreferences = await response.json()
      setPreferences(storedPreferences)
      setEditorValue(JSON.stringify(storedPreferences, null, 2))
      setNotice('Preferences saved.')
    } catch (error) {
      setNotice(error instanceof SyntaxError ? 'Enter valid JSON before saving.' : error.message)
    }
  }

  return (
    <div className="preferences-page">
      <header className="page-heading">
        <div>
          <p className="eyebrow">Display settings</p>
          <h1>Preferences</h1>
          <p className="muted">Edit the JSON object saved by the local preferences API.</p>
        </div>
      </header>

      <div className="preferences-layout">
        <form className="preferences-card" onSubmit={savePreferences}>
          <label className="text-entry-label" htmlFor="preferences-json">Preference object (JSON)</label>
          <textarea
            id="preferences-json"
            className="preferences-input"
            value={editorValue}
            onChange={(event) => setEditorValue(event.target.value)}
            spellCheck="false"
            rows={12}
          />
          <div className="preferences-actions">
            <button className="button button-dark" type="submit">Save preferences</button>
            <p className="preferences-status" role="status">{notice}</p>
          </div>
        </form>

        <section className="preferences-card" aria-labelledby="preferences-output-heading">
          <p className="eyebrow">Rendered output</p>
          <h2 id="preferences-output-heading">Preference props</h2>
          <div className="preferences-rendered">
            {/* INTENTIONAL LAB VULNERABILITY: API props, including dangerouslySetInnerHTML, are spread directly here. */}
            <div {...preferences} />
          </div>
        </section>
      </div>
    </div>
  )
}

export default Preferences
