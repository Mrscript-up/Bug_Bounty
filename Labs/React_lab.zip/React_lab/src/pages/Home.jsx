import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { products } from '../data/products.js'
import ProductCard from '../components/ProductCard.jsx'

// این کامپوننت نمونه‌ای از state محلی است و با تغییر state دوباره رندر می‌شود.
function Counter() {
  const [count, setCount] = useState(0)

  return (
    <div className="counter-card">
      <div>
        <p className="eyebrow">A tiny React demo</p>
        <h3>Click counter</h3>
        <p className="muted">The current value lives in this component's state.</p>
      </div>
      <button className="button button-outline" type="button" onClick={() => setCount((currentCount) => currentCount + 1)}>
        Clicked {count} {count === 1 ? 'time' : 'times'}
      </button>
      {/* ری‌اکت تغییر این state را با خروجی قبلی مقایسه می‌کند و بخش لازم رابط را دوباره می‌سازد. */}
      <div>
        <p className="eyebrow">A tiny React demo</p>
        <h3>Click counter</h3>
        <p className="muted">The current value lives in this component's state.</p>
      </div>
      <button className="button button-outline" type="button" onClick={() => setCount((currentCount) => currentCount + 1)}>
        Clicked {count} {count === 1 ? 'time' : 'times'}
      </button>
      {/* ری‌اکت تغییر این state را با خروجی قبلی مقایسه می‌کند و بخش لازم رابط را دوباره می‌سازد. */}
    </div>
  )
}

function RefPreviewLab() {
  const [message, setMessage] = useState('')
  const boxRef = useRef(null)

  useEffect(() => {
    if (boxRef.current) {
      // INTENTIONAL XSS LAB: user-controlled input is assigned to innerHTML without sanitization.
      boxRef.current.innerHTML = message || 'Your text will appear here.'
    }
  }, [message])

  return (
    <section className="text-entry-card">
      <div>
        <p className="eyebrow">A tiny writing space</p>
        <h2>Write something</h2>
        <label className="text-entry-label" htmlFor="home-message">
          Your text
        </label>
        <textarea
          id="home-message"
          className="text-entry-input"
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          placeholder="Type a note or thought..."
          rows={3}
        />
      </div>
      <div className="text-entry-preview" aria-live="polite">
        <p className="eyebrow">Preview</p>
        <p
          ref={boxRef}
          className={message ? 'text-entry-message' : 'text-entry-placeholder'}
        />
      </div>
    </section>
  )
}

function Home() {
  return (
    <div className="home-page">
      <section className="hero-panel">
        <div className="hero-copy">
          <p className="eyebrow">A little shop, a lot to learn</p>
          <h1>Good things for <span>everyday living.</span></h1>
          <p className="hero-description">
            Browse a handful of thoughtful finds while exploring how a React app fits together.
          </p>
          <Link className="button button-dark" to="/products">Explore products <span aria-hidden="true">↗</span></Link>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="hero-sun" />
          <span className="hero-emoji hero-emoji-one">🪴</span>
          <span className="hero-emoji hero-emoji-two">☕</span>
          <span className="hero-emoji hero-emoji-three">🎒</span>
          <span className="hero-note">small joys<br />for every day</span>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <p className="eyebrow">A few favorites</p>
            <h2>Meet the little collection</h2>
          </div>
          <Link className="plain-link" to="/products">View all products <span aria-hidden="true">→</span></Link>
        </div>
        <div className="product-grid product-grid-featured">
          {products.slice(0, 3).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* این بلوک درباره DOM مجازی است: تغییر شمار سبد در Navbar نیز فقط بخش‌های وابسته به آن را به‌روز می‌کند. */}
      <section className="learning-note">
        <span className="learning-icon" aria-hidden="true">✳</span>
        <div>
          <p className="eyebrow">A note about React</p>
          <h2>Small updates, smooth interface.</h2>
          <p>When cart state changes, React compares its new virtual UI with the previous one and updates the affected screen output.</p>
        </div>
      </section>
      <section className="learning-note">
        <span className="learning-icon" aria-hidden="true">✳</span>
        <div>
          <p className="eyebrow">A note about React</p>
          <h2>Small updates, smooth interface.</h2>
          <p>When cart state changes, React compares its new virtual UI with the previous one and updates the affected screen output.</p>
          <Link className="plain-link" to="/products">View all products <span aria-hidden="true">→</span></Link>
        </div>
      </section>

      <Counter />

      <RefPreviewLab />
    </div>
  )
}

export default Home
