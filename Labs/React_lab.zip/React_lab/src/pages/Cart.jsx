import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import CartItem from '../components/CartItem.jsx'
import { clearCart } from '../store/cartSlice.js'

function Cart() {
  const items = useSelector((state) => state.cart.items)
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const subtotal = items.reduce((total, item) => total + item.product.price * item.quantity, 0)
  const itemCount = items.reduce((total, item) => total + item.quantity, 0)

  // useNavigate بعد از ثبت سفارش، سبد را پاک می‌کند و کاربر را به صفحه خانه می‌برد.
  function handlePlaceOrder() {
    dispatch(clearCart())
    navigate('/products')
  }

  return (
    <section className="cart-page">
      <div className="page-heading cart-heading">
        <div>
          <p className="eyebrow">Your picks</p>
          <h1>Shopping cart</h1>
          <p className="muted">{itemCount} {itemCount === 1 ? 'item' : 'items'} in your cart</p>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="empty-state cart-empty">
          <span className="empty-bag" aria-hidden="true">🛍️</span>
          <h2>Your cart is taking a little break.</h2>
          <p>Find something nice to bring along.</p>
          <button className="button button-dark" type="button" onClick={() => navigate('/products')}>
            Browse products
          </button>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="cart-items-list">
            {items.map((item) => <CartItem key={item.product.id} item={item} />)}
          </div>
          <aside className="order-summary">
            <p className="eyebrow">Your order</p>
            <h2>Summary</h2>
            <div className="summary-row">
              <span>Subtotal</span>
              <strong>${subtotal.toFixed(2)}</strong>
            </div>
            <div className="summary-row muted">
              <span>Shipping</span>
              <span>Free</span>
            </div>
            <div className="summary-total">
              <span>Total</span>
              <strong>${subtotal.toFixed(2)}</strong>
            </div>
            <button className="button button-dark checkout-button" type="button" onClick={handlePlaceOrder}>
              Place order <span aria-hidden="true">→</span>
            </button>
            <p className="summary-note">This demo checkout clears your cart and returns you home.</p>
          </aside>
        </div>
      )}
    </section>
  )
}

export default Cart
