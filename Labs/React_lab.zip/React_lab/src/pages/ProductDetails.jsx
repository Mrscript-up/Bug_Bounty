import { Link, useParams } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { products } from '../data/products.js'
import { addItem } from '../store/cartSlice.js'

function ProductDetails() {
  // useParams شناسه پویای محصول را از نشانی مسیر می‌خواند.
  const { id } = useParams()
  const product = products.find((item) => String(item.id) === id)
  const dispatch = useDispatch()

  if (!product) {
    return (
      <section className="empty-state details-not-found">
        <p className="eyebrow">Product not found</p>
        <h1>We couldn't find that item.</h1>
        <Link className="button button-dark" to="/products">Back to products</Link>
      </section>
    )
  }

  return (
    <section className="detail-layout">
      <div className="detail-art" style={{ '--product-color': product.color }} aria-hidden="true">
        <span>{product.emoji}</span>
        <span className="detail-art-caption">mini shop / no. {String(product.id).padStart(2, '0')}</span>
      </div>
      <div className="detail-copy">
        <Link className="back-link" to="/products">← All products</Link>
        <p className="eyebrow">{product.category}</p>
        <h1>{product.name}</h1>
        <p className="detail-description">{product.description}</p>
        <p className="detail-price">${product.price.toFixed(2)}</p>
        <button className="button button-dark" type="button" onClick={() => dispatch(addItem(product))}>
          Add to cart <span aria-hidden="true">+</span>
        </button>
        <p className="detail-footnote">A lovely little pick, ready for your everyday.</p>
      </div>
    </section>
  )
}

export default ProductDetails
