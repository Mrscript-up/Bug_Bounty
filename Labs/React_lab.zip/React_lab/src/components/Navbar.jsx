import { Link, NavLink } from 'react-router-dom'
import { useSelector } from 'react-redux'

// این کامپوننت کوچک و قابل استفاده دوباره، پیوندهای صفحه‌ها و شمارنده سبد را نشان می‌دهد.
function Navbar() {
  const items = useSelector((state) => state.cart.items)
  const cartCount = items.reduce((total, item) => total + item.quantity, 0)

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="brand" to="/" aria-label="Mini Shop home">
          <span className="brand-mark" aria-hidden="true">m</span>
          <span>mini shop</span>
        </Link>

        <nav className="main-nav" aria-label="Main navigation">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/products">Products</NavLink>
          <NavLink className="cart-link" to="/cart">
            Cart <span className="cart-count">{cartCount}</span>
          </NavLink>
          <NavLink to="/preferences">Preferences</NavLink>
          <NavLink to="/about">About</NavLink>
        </nav>
      </div>
    </header>
  )
}

export default Navbar
