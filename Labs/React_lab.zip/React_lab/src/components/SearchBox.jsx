// این کامپوننت فرزند مقدار جست‌وجو را از والد می‌گیرد و تغییر را با تابع callback درخواست می‌کند.
function SearchBox({ value, onChange }) {
  return (
    <label className="search-box">
      <span className="visually-hidden">Search products</span>
      <span className="search-icon" aria-hidden="true">⌕</span>
      <input
        type="search"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Search products..."
      />
    </label>
  )
}

export default SearchBox
