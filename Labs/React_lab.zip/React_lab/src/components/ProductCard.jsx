import { Link } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { addItem } from '../store/cartSlice.js'

// این کامپوننت قابل استفاده دوباره است و برای هر محصول، داده را از طریق props می‌گیرد.
function ProductCard({ product }) {
  const dispatch = useDispatch()

  return (
    <article className="product-card">
      <Link className="product-art" to={`/product/${product.id}`} style={{ '--product-color': product.color }}>
        <span aria-hidden="true">{product.emoji}</span>
      </Link>
      <div className="product-card-content">
        <p className="eyebrow">{product.category}</p>
        <h3><Link to={`/product/${product.id}`}>{product.name}</Link></h3>
        <div className="product-card-footer">
          <strong>${product.price.toFixed(2)}</strong>
          <button className="button button-small button-dark" type="button" onClick={() => dispatch(addItem(product))}>
            Add to cart
          </button>
        </div>
      </div>
    </article>
  )
}

export default ProductCard
