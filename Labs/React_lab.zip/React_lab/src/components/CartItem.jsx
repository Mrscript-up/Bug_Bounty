import { useDispatch } from 'react-redux'
import { addItem, removeItem } from '../store/cartSlice.js'

// این کامپوننت قابل استفاده دوباره، ردیف یک محصول را در سبد خرید نمایش می‌دهد.
function CartItem({ item }) {
  const dispatch = useDispatch()
  const { product, quantity } = item

  return (
    <article className="cart-item">
      <div className="cart-item-art" style={{ '--product-color': product.color }} aria-hidden="true">
        {product.emoji}
      </div>
      <div className="cart-item-info">
        <p className="eyebrow">{product.category}</p>
        <h3>{product.name}</h3>
        <p className="muted">${product.price.toFixed(2)} each</p>
      </div>
      <div className="quantity-control" aria-label={`Quantity: ${quantity}`}>
        <button type="button" onClick={() => dispatch(addItem(product))} aria-label={`Add one ${product.name}`}>
          +
        </button>
        <span>{quantity}</span>
      </div>
      <strong className="cart-line-total">${(product.price * quantity).toFixed(2)}</strong>
      <button className="text-button remove-button" type="button" onClick={() => dispatch(removeItem(product.id))}>
        Remove
      </button>
    </article>
  )
}

export default CartItem
