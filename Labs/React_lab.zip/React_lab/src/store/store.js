import { configureStore } from '@reduxjs/toolkit'
import cartReducer from './cartSlice.js'

// این فروشگاه مرکزی reducer سبد را نگه می‌دارد تا همه صفحه‌ها state مشترک ببینند.
export const store = configureStore({
  reducer: {
    cart: cartReducer,
  },
})
