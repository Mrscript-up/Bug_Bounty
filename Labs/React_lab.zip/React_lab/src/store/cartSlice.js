import { createSlice } from '@reduxjs/toolkit'

// نگاشت Flux در این برنامه چنین است: View -> Action -> Reducer -> Store -> View؛ کلیک View یک Action می‌فرستد، Reducer فروشگاه را به‌روزرسانی می‌کند و View تازه نمایش داده می‌شود.
// این برش، state سبد و سه عمل اصلی آن را با الگوی Redux Toolkit تعریف می‌کند.
const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    items: [],
  },
  reducers: {
    // این عمل یک محصول را اضافه می‌کند یا تعداد محصول موجود را افزایش می‌دهد.
    addItem(state, action) {
      const product = action.payload
      const existingItem = state.items.find((item) => item.product.id === product.id)

      if (existingItem) {
        existingItem.quantity += 1
      } else {
        state.items.push({ product, quantity: 1 })
      }
      
    },
    // این عمل محصول انتخاب‌شده را به‌طور کامل از سبد حذف می‌کند.
    removeItem(state, action) {
      state.items = state.items.filter((item) => item.product.id !== action.payload)
    },
    // این عمل همه محصولات سبد خرید را پاک می‌کند.
    clearCart(state) {
      state.items = []
    },
  },
})

export const { addItem, removeItem, clearCart } = cartSlice.actions
export default cartSlice.reducer
